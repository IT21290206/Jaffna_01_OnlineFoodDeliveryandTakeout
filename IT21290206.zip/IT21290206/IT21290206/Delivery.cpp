#include<iostream>
#include"Delivery.h"
#include<cstring>
using namespace std;

void Delivery::SetOrderDetails(const char Oid[], double Price, int pno, float dfee)
{
	Price = Price;
	Phoneno = pno;
	D_fee = dfee;
}

void Delivery::Calcprice()
{

}

void Delivery::Calctotal()
{

}

void Delivery::CalcDiscount()
{

}