#pragma once
#include"Delivery.h"
class DeliveryBoy
{
private:
	int Age;
	char DOB[20];
	char Device[50];
	int Licenseno;
	Delivery* De;
public:
	void Vieworder();
	void Confirmorder();
	void Viewcustomerdetails();
	void Seefeedback();
};
