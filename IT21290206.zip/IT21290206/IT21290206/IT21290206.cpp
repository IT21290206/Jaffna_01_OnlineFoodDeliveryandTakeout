#include <iostream>
#include"Delivery.h"
#include"DeliveryBoy.h"
    using namespace std;
    int main()
    {
        Delivery* dv;
        dv = new Delivery();
        DeliveryBoy* db;
        db = new DeliveryBoy();
    }
