#include "DeliveryBoy.h"
#include<iostream>
using namespace std;
#include<cstring>

void DeliveryBoy::Vieworder()
{

}

void DeliveryBoy::Confirmorder()
{

}

void DeliveryBoy::Viewcustomerdetails()
{

}

void DeliveryBoy::Seefeedback()
{

}
