#pragma once
#include"DeliveryBoy.h"
#include"Order.h"
class Delivery : public Order
{
private:
	int Phoneno;
	float D_fee;
	int Price;
	DeliveryBoy* DB;
	Order* OR;
public:
	void SetOrderDetails(const char Oid[], double Price, int pno, float dfee);
	void Calcprice();
	void Calctotal();
	void CalcDiscount();

};